import 'package:chem/Pages/Youtube/youtube_page.dart';
import 'package:chem/localization/localization_constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class Youtube_Grade extends StatefulWidget {
  const Youtube_Grade({Key? key}) : super(key: key);

  @override
  _Youtube_GradeState createState() => _Youtube_GradeState();
}

class _Youtube_GradeState extends State<Youtube_Grade> {

  int numb = 1;
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
          getTranslated(context, 'Books'),
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 80,
              decoration: BoxDecoration(
                color: Colors.orange,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,

                children: [
                  SvgPicture.asset(
                    'assets/Icons/Chem_videos.svg',
                    height: 40.0,
                    width: 40.0,
                  ),
                  SizedBox(width: 8,),
                  Text(
                    getTranslated(context, 'Videos'),
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 30),
                  )
                ],
              ),
            ),
          ),
          //Title Listile

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('صنف اول',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Youtube_Page(value:numb)));
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '2',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text(
                  'Grade 1',
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '3',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '4',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '5',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '6',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '7',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '8',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '9',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '10',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '11',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.orange,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    '12',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ),
                title: Text('Grade 1',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),
          ),
        ],
      ),
    );
  }
}
