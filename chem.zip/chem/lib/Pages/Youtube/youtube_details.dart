import 'dart:async';

import 'package:chem/localization/localization_constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class Youtube_Video_Details extends StatefulWidget {
  final Videos_details;
  const Youtube_Video_Details({Key? key, required this.Videos_details})
      : super(key: key);

  @override
  _Youtube_Video_DetailsState createState() => _Youtube_Video_DetailsState();
}

class _Youtube_Video_DetailsState extends State<Youtube_Video_Details> {
  bool loading = true;
  String? Video_ID;
  YoutubePlayerController? _controller;

//  Getting PDF and convert to PDFDocument using below function
  Future Video_load() async {
    RegExp regExp = new RegExp(
      r'.*(?:(?:youtu\.be\/|v\/|vi\/|u\/\w\/|embed\/)|(?:(?:watch)?\?v(?:i)?=|\&v(?:i)?=))([^#\&\?]*).*',
      caseSensitive: false,
      multiLine: false,
    );
    final match = regExp
        .firstMatch(widget.Videos_details)
        ?.group(1); // <- This is the fix
    Video_ID = match;
    setState(() {
      loading = false;
    });
  }

  //All functions get called using initState
  @override
  void initState() {
     _controller = YoutubePlayerController(
        initialVideoId: Video_ID!,
        flags: YoutubePlayerFlags(
          hideControls: false,
          controlsVisibleAtStart: false,
          autoPlay: true,
          mute: false,
          isLive: false,
          hideThumbnail: false,
        ));
    // TOO: implement initState
    super.initState();
    Video_load();
  }

  void dispose() {
   _controller?.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          getTranslated(context, 'Books'),
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: OrientationBuilder(
        builder: (context, orientation) =>
            orientation == Orientation.portrait ? Vertical() : Landscape(),
      ),
    );
  }

  Widget Vertical() {
    return Center(
      child: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.5,
                child: loading
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : YoutubePlayer(
                        controller: _controller!,
                        showVideoProgressIndicator: true,
                        progressIndicatorColor: Colors.orange,
                        progressColors: ProgressBarColors(
                          playedColor: Colors.orange,
                          handleColor: Colors.orangeAccent,
                        ),
                      ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget Landscape() {
    return Center(
      child: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.5,
                width: MediaQuery.of(context).size.width * 0.8,
                child: loading
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : YoutubePlayer(
                        controller:_controller!,
                        showVideoProgressIndicator: true,
                        progressIndicatorColor: Colors.orange,
                        progressColors: ProgressBarColors(
                          playedColor: Colors.orange,
                          handleColor: Colors.orangeAccent,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
