import 'package:chem/Pages/Youtube/youtube_details.dart';
import 'package:chem/localization/localization_constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Youtube_Page extends StatefulWidget {
  final value;
  const Youtube_Page({Key? key, this.value}) : super(key: key);

  @override
  _Youtube_PageState createState() => _Youtube_PageState();
}

class _Youtube_PageState extends State<Youtube_Page> {
  bool isSearching = false;
  FirebaseFirestore _Videos = FirebaseFirestore.instance;
  List<DocumentSnapshot> Videos_details = [];
  List<DocumentSnapshot> _book_details_filter_Data = [];
  int _Videos_per_page = 10;
  late DocumentSnapshot _lastDocument;
  ScrollController _scrollController = ScrollController();
  bool _gettingMoreVideos = false;
  bool _moreVideosAvailable = true;
  bool _loadingVideos = true;

  _getVideos() async {
    Query q = _Videos.collection("chem_videos")
        .where("Video_Grade", isEqualTo: widget.value)
        .limit(_Videos_per_page);
    setState(() {
      _loadingVideos = true;
    });
    QuerySnapshot querySnapshot = await q.get();
    Videos_details = querySnapshot.docs;
    _lastDocument = querySnapshot.docs[querySnapshot.docs.length - 1];

    setState(() {
      _loadingVideos = false;
    });
  }

  _getMoreVideos() async {
    print("Get more Books called");
    if (_moreVideosAvailable == false) {
      return;
    }
    if (_gettingMoreVideos == true) {
      return;
    }

    _gettingMoreVideos = true;

    Query q = _Videos.collection("chem_videos")
        .where("Video_Grade", isEqualTo: widget.value)
        .startAfter([_lastDocument['Video_Title']]).limit(_Videos_per_page);
    QuerySnapshot querySnapshot = await q.get();

    if (querySnapshot.docs.length < _Videos_per_page) {
      _moreVideosAvailable = false;
    }

    _lastDocument = querySnapshot.docs[querySnapshot.docs.length - 1];
    Videos_details.addAll(querySnapshot.docs);
    _gettingMoreVideos = false;
  }

  @override
  void initState() {
    _getVideos();
    super.initState();
    _scrollController.addListener(() {
      double maxScroll = _scrollController.position.maxScrollExtent;
      double currentScroll = _scrollController.position.pixels;
      double delta = MediaQuery.of(context).size.height * 0.25;
      if (maxScroll - currentScroll <= delta) {
        _getMoreVideos();
      }
    });
  }

  void _FilterBooks(value) {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: !isSearching
              ? Text(getTranslated(context, 'Videos'))
              : TextField(
                  onChanged: (value) {
                    // _FilterBooks(value);
                  },
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      icon: Icon(
                        Icons.search,
                        color: Colors.black,
                      ),
                      hintText: getTranslated(context, 'Search Here'),
                      hintStyle: TextStyle(color: Colors.black)),
                ),
          actions: <Widget>[
            isSearching
                ? IconButton(
                    icon: Icon(Icons.cancel),
                    onPressed: () {
                      setState(() {
                        this.isSearching = false;
                      });
                    },
                  )
                : IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      setState(() {
                        this.isSearching = true;
                      });
                    },
                  )
          ],
        ),
        body: _loadingVideos == true
            ? Card(
                child: Center(
                  child: Text("Loading ..."),
                ),
              )
            : Card(
                child: Videos_details.length == 0
                    ? Center(
                        child: Text("No Videos To Load"),
                      )
                    : _listView(context)));
  }

  ListView _listView(BuildContext context) {
    return ListView.builder(
        controller: _scrollController,
        itemCount: Videos_details.length,
        itemBuilder: (BuildContext ctx, int index) {
          return Column(mainAxisSize: MainAxisSize.min, children: [
            Card(
              margin: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
              child: ListTile(
                tileColor: Colors.orange,
                isThreeLine: true,
                title: Container(
                  height: 80,
                  child: Text(
                    (Videos_details[index]['Video_Title']).toString(),
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0),
                  ),
                ),
                subtitle: Container(
                  height: 18,
                  alignment: Alignment.bottomLeft,
                  child: RichText(
                    text: TextSpan(
                      children: [
                        WidgetSpan(
                          child: Icon(Icons.timelapse, size: 18),
                        ),
                        TextSpan(
                          text: '' + Videos_details[index]['Video_Duration'],
                          style: TextStyle(color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => Youtube_Video_Details(
                          Videos_details: Videos_details[index]
                              ['Video_Links'])));
                },
                trailing: Icon(Icons.arrow_forward),
                leading:
                ConstrainedBox(
                  constraints: BoxConstraints.expand(
                    height: 110,
                    width: 100,
                  ),
                  child: Image.network(
                    Videos_details[index]['Video_Thumbnail'],
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ]);
        });
  }
}
