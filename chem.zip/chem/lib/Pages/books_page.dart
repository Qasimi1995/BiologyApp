import 'package:advance_pdf_viewer_fork/advance_pdf_viewer_fork.dart';
import 'package:chem/localization/localization_constants.dart';
import 'package:chem/routes/route_name.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:getwidget/getwidget.dart';
import 'package:intl/intl.dart';

import 'books_details_page.dart';

class Books_page extends StatefulWidget {
  var value;
  Books_page({Key? key, this.value}) : super(key: key);

  @override
  _Books_pageState createState() => _Books_pageState();
}

class _Books_pageState extends State<Books_page> {
  bool isSearching = false;
  FirebaseFirestore _Books = FirebaseFirestore.instance;
  List<DocumentSnapshot> book_details = [];
  List<DocumentSnapshot> _book_details_filter_Data = [];
  int _books_per_page = 10;
  late DocumentSnapshot _lastDocument;
  ScrollController _scrollController = ScrollController();
  bool _gettingMoreBooks = false;
  bool _moreBooksAvailable = true;
  bool _loadingBooks = true;
  _getBooks() async {
    Query q = _Books.collection("chem_book")
        .where("Grade_Name", isEqualTo: widget.value)
        .limit(_books_per_page);
    setState(() {
      _loadingBooks = true;
    });
    QuerySnapshot querySnapshot = await q.get();
    book_details = querySnapshot.docs;
    _lastDocument = querySnapshot.docs[querySnapshot.docs.length - 1];

    setState(() {
      _loadingBooks = false;
    });
  }

  _getMoreBooks() async {
    print("Get more Books called");
    if (_moreBooksAvailable == false) {
      return;
    }
    if (_gettingMoreBooks == true) {
      return;
    }

    _gettingMoreBooks = true;

    Query q = _Books.collection("chem_book")
        .where("Grade_Name", isEqualTo: widget.value)
        .startAfter([_lastDocument['Book_Name']]).limit(_books_per_page);
    QuerySnapshot querySnapshot = await q.get();

    if (querySnapshot.docs.length < _books_per_page) {
      _moreBooksAvailable = false;
    }

    _lastDocument = querySnapshot.docs[querySnapshot.docs.length - 1];
    book_details.addAll(querySnapshot.docs);
    _gettingMoreBooks = false;
  }

  @override
  void initState() {
    _getBooks();
    super.initState();
    _scrollController.addListener(() {
      double maxScroll = _scrollController.position.maxScrollExtent;
      double currentScroll = _scrollController.position.pixels;
      double delta = MediaQuery.of(context).size.height * 0.25;
      if (maxScroll - currentScroll <= delta) {
        _getMoreBooks();
      }
    });
  }

  void _FilterBooks(value) {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: !isSearching
              ? Text(getTranslated(context, 'Books'))
              : TextField(
                  onChanged: (value) {
                    // _FilterBooks(value);
                  },
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      icon: Icon(
                        Icons.search,
                        color: Colors.black,
                      ),
                      hintText: getTranslated(context, 'Search Here'),
                      hintStyle: TextStyle(color: Colors.black)),
                ),
          actions: <Widget>[
            isSearching
                ? IconButton(
                    icon: Icon(Icons.cancel),
                    onPressed: () {
                      setState(() {
                        this.isSearching = false;
                      });
                    },
                  )
                : IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      setState(() {
                        this.isSearching = true;
                      });
                    },
                  )
          ],
        ),
        body: _loadingBooks == true
            ? Card(
                child: Center(
                  child: Text("Loading ..."),
                ),
              )
            : Card(
                child: book_details.length == 0
                    ? Center(
                        child: Text("No Books To Show"),
                      )
                    : _listView(context)));
  }

  ListView _listView(BuildContext context) {
    return ListView.builder(
        controller: _scrollController,
        itemCount: book_details.length,
        itemBuilder: (BuildContext ctx, int index) {
          return Column(mainAxisSize: MainAxisSize.min, children: [
            Card(
              margin: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              child: ListTile(
                tileColor: Colors.orange,
                isThreeLine: true,
                title: Container(
                  height: 80,
                  child: Text(
                    (book_details[index]['Book_Name']).toString(),
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0),
                  ),
                ),
                subtitle: Container(
                  height: 18,
                  alignment: Alignment.bottomLeft,
                  child: RichText(
                    text: TextSpan(
                      children: [
                        WidgetSpan(
                          child: Icon(Icons.date_range, size: 18),
                        ),
                        TextSpan(
                          text: '' +
                              DateFormat('dd-MM-yyyy')
                                  .format((book_details[index]
                                          ['Book_Publish_Date']
                                      .toDate()))
                                  .toString(),
                          style: TextStyle(color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => Book_details(
                          book_detail: book_details[index]['Book_PDF'])));
                },
                dense: true,
                trailing: Icon(Icons.arrow_forward),
                leading: ConstrainedBox(
                  constraints: BoxConstraints(
                    minWidth: 70,
                    minHeight: 60,
                    maxWidth: 70,
                    maxHeight: 60,
                  ),
                  child: Image.network(
                    book_details[index]['Book_Image'],
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ]);
        });
  }
}
