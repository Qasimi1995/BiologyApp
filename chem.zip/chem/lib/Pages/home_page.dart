import 'package:flutter_svg/flutter_svg.dart';
import 'package:carousel_pro_nullsafety/carousel_pro_nullsafety.dart';
import 'package:chem/classes/language.dart';
import 'package:chem/localization/localization_constants.dart';
import 'package:chem/main.dart';
import 'package:chem/routes/route_name.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  void _showSuccessDialog() {
    showTimePicker(context: context, initialTime: TimeOfDay.now());
  }

  void _changeLanguage(Language language) async {
    //print(language.languageCode);
    Locale _temp = await setLocale(language.languageCode);
    MyAppHome.setLocale(context, _temp);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: <Color>[
                  Colors.orange,
                  Colors.orangeAccent
                ],)
              ),
              child: Container(
                child: Column(
                  children: <Widget>[
                    Material(
                      borderRadius: BorderRadius.all(Radius.circular(100.0)),
                      elevation: 10,
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Image.asset(
                          'assets/chemistrym.png',
                          width: 80,
                          height: 80,
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Chemistry ',
                        style: TextStyle(color: Colors.white, fontSize: 20.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.group),
              title: Text(getTranslated(context, 'About Page')),
              onTap: () {
                Navigator.pushNamed(context, aboutRoute);
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text(getTranslated(context, 'Settings')),
              onTap: () {
                Navigator.pushNamed(context, settingsRoute);
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title:
            //Using Localization class to localize the app in three language as below
            Text(getTranslated(context, 'Home Page')),
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.all(8.0),
            child: DropdownButton(
              underline: SizedBox(),
              icon: Icon(
                Icons.language,
                color: Colors.white,
              ),
              items: Language.languageList()
                  .map<DropdownMenuItem<Language>>((lang) => DropdownMenuItem(
                        value: lang,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            Text(lang.flag),
                            Text(
                              lang.name,
                              style: TextStyle(fontSize: 30),
                            )
                          ],
                        ),
                      ))
                  .toList(),
              onChanged: (Language? language) {
                _changeLanguage(language!);
              },
            ),
          ),
        ],
      ),
      body: OrientationBuilder(
        builder: (context, orientation) =>
            orientation == Orientation.portrait ? Vertical() : Landscap(),
      ),
    );
  }

  //Home Page for Vertical View
  Widget Vertical() {
    return ListView(
      children: <Widget>[
        Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              margin: const EdgeInsets.only(left: 2.0, right: 2.0, top: 2.0),
              child: Center(
                child: ListView(
                  children: [
                    SizedBox(
                      height: 200.0,
                      width: double.infinity,
                      child: Carousel(
                        images: [
                          Image.asset(
                            'assets/slider/3.jpg',
                            fit: BoxFit.cover,
                          ),
                          Image.asset(
                            'assets/slider/2.jpg',
                            fit: BoxFit.cover,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Container(
                height: MediaQuery.of(context).size.height * 0.6,
                child: CustomScrollView(
                  primary: false,
                  slivers: <Widget>[
                    SliverPadding(
                      padding: const EdgeInsets.only(
                          left: 20, right: 20, bottom: 30),
                      sliver: SliverGrid.count(
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        crossAxisCount: 2,
                        children: <Widget>[
                          InkWell(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.orange,
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SvgPicture.asset(
                                    'assets/Icons/Chem_videos.svg',
                                    height: 70.0,
                                    width: 70.0,
                                  ),
                                  Text(
                                    getTranslated(context, 'Videos'),
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 25),
                                  )
                                ],
                              ),
                            ),
                            onTap: () {
                              Navigator.pushNamed(context, youtubeGradeRoute);
                            },
                          ),
                          InkWell(
                            child:
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.orange,
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SvgPicture.asset(
                                    'assets/Icons/Chem_books.svg',
                                    height: 70.0,
                                    width: 70.0,
                                  ),
                                  Text(
                                    getTranslated(context, 'Books'),
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 25),
                                  ),
                                ],
                              ),
                            ),
                            onTap: () {
                              Navigator.pushNamed(context, booksGradeRoute);
                            },
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_articles.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Articles'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_courses.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Courses'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_kankor.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Kankor'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_general.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'General'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )),
          ],
        ),
      ],
    );
  }

  //Home Page for Landscap View
  Widget Landscap() {
    return ListView(
      children: <Widget>[
        Column(
          children: [
            /* Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.3,
              margin: const EdgeInsets.only(left: 2.0, right: 2.0, top: 2.0),
              child: Center(
                child: ListView(
                  children: [
                    SizedBox(
                      height: 200.0,
                      width: double.infinity,
                      child:
                      Carousel(
                        images: [
                          Image.asset(
                            'assets/slider/3.jpg',
                            fit: BoxFit.cover,
                          ),
                          Image.asset(
                            'assets/slider/2.jpg',
                            fit: BoxFit.cover,
                          )
                        ],
                      ),
                    )
                  ],
                ),

              ),
            ),
            */
            Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.7,
                child: CustomScrollView(
                  primary: false,
                  slivers: <Widget>[
                    SliverPadding(
                      padding: const EdgeInsets.only(
                          left: 20, right: 20, bottom: 5, top: 30),
                      sliver: SliverGrid.count(
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        crossAxisCount: 3,
                        children: <Widget>[
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_videos.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Videos'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_books.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Books'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_articles.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Articles'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_courses.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Courses'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_kankor.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'Kankor'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/Icons/Chem_general.svg',
                                  height: 70.0,
                                  width: 70.0,
                                ),
                                Text(
                                  getTranslated(context, 'General'),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )),
          ],
        ),
      ],
    );
  }
}
