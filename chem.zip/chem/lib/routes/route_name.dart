const String homeRoute = '/';
const String aboutRoute = 'about';
const String settingsRoute = 'settings';
const String videosRoute = 'videos';
const String booksRoute = 'books';
const String articleRoute = 'article';
const String coursesRoute = 'courses';
const String kankorRoute = 'kankor';
const String generalRoute = 'general';
const String bookEntryRoute = 'Books_entry';
const String detailsPageRoute='Details_Book_Page';
const String booksGradeRoute = '_Books_Grade';
const String youtubeGradeRoute = '_Youtube_Grade';



