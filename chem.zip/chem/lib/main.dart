import 'package:chem/localization/localization_chem.dart';
import 'package:chem/routes/custome_router.dart';
import 'package:chem/routes/route_name.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'localization/localization_constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FlutterDownloader.initialize(
      debug: true // optional: set false to disable printing logs to console
  );
  runApp(MyAppHome());
}

class MyAppHome extends StatefulWidget {
  const MyAppHome({Key? key}) : super(key: key);

  static void setLocale(BuildContext context, Locale locale) {
    _MyAppHomeState? state = context.findAncestorStateOfType<_MyAppHomeState>();
    state?.setLocale(locale);
  }

  @override
  State<MyAppHome> createState() => _MyAppHomeState();
}

class _MyAppHomeState extends State<MyAppHome> {
  Locale? _locale;

  void setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  void didChangeDependencies() {
    getLocale().then((locale) {
      setState(() {
        this._locale = locale;
      });
    });
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    if (_locale == null) {
      return Container(
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else{
      return MaterialApp(
        title: 'Chemistry App',
        theme: ThemeData(
          primarySwatch: Colors.orange,
        ),
        locale: _locale,
        supportedLocales: [
          Locale('en','US'),
          Locale('fa','IR'),
          Locale('ps', 'ps-AR')
        ],
        localizationsDelegates: [
          LocalizationChem.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],

        localeResolutionCallback: (deviceLocal, supportedLocales){
          for(var locale in supportedLocales){
            if(locale.languageCode == deviceLocal!.languageCode && locale.countryCode == deviceLocal.countryCode){
              return deviceLocal;
            }
          }
          return supportedLocales.first;
        },
        debugShowCheckedModeBanner: false,
        onGenerateRoute: CustomRouter.allRoutes,
        initialRoute: homeRoute,
      );
    }

  }
}
